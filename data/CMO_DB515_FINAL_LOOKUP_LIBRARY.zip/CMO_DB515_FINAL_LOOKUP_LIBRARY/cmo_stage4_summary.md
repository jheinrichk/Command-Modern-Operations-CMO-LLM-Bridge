# CMO DB3K Stage-4 Extraction Summary

- Source DB: `C:\Program Files (x86)\Steam\steamapps\common\Command - Modern Operations\DB\DB3K_515.db3`
- Corrected platform records: `18888`
- Aircraft records: `7630`
- Aircraft/loadout relationships: `99186`
- Aircraft/loadout/weapon rows: `264659`
- Aircraft with at least one loadout: `7630`

## Key outputs

- `cmo_aircraft_loadouts.csv` — authoritative aircraft DBID -> loadout DBID relationship
- `cmo_aircraft_loadout_weapons.csv` — raw aircraft -> loadout -> weapon-record component rows
- `cmo_aircraft_loadout_weapon_totals.csv` — corrected weapon counts using DataWeaponRecord.DefaultLoad
- `cmo_target_aircraft_variant_audit.csv` — confirms the country/service actually attached to each target DBID
- `cmo_aircraft_loadouts.lua` — nested Lua lookup table
- `cmo_target_aircraft_loadout_report.md` — readable report for the nine aircraft used in the Hormuz 2026 work
- `cmo_platform_lookup_corrected.csv` — corrected platform catalog built from DataAircraft/DataShip/DataSubmarine/DataFacility/DataGroundUnit/DataSatellite

## Stage-1 correction

Stage 1 selected `EnumAircraftFacilityType` instead of the real platform tables. Stage 2 corrected the platform and aircraft/loadout relationship but skipped `DataWeaponRecord`. Stage 3 corrected the table chain. Stage 4 also corrects the field semantics: `DataLoadoutWeapons.ComponentNumber` is preserved as the component ordinal while `DataWeaponRecord.DefaultLoad` and `MaxLoad` are used as the weapon quantities.
